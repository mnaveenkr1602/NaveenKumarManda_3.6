package bean;

public class BookCab {
	
	private int bookingId;
	private User user;
	private Cab cab;
	
	BookCab(int bookingId, User user, Cab cab){
		this.bookingId=bookingId;
		this.user=user;
		this.cab=cab;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Cab getCab() {
		return cab;
	}

	public void setCab(Cab cab) {
		this.cab = cab;
	}
	
	

}
