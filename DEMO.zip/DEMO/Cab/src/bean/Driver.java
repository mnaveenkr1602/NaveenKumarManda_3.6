package bean;

@Component
public class Driver {

	private String driverName;
	private int mobileNumber;
	
	Driver (String driver,int mobileNumber){
		this.driverName=driverName;
		this.mobileNumber=mobileNumber;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public int getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(int mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	
}
