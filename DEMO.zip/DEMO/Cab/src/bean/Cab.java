package bean;

@Component
public class Cab {
	private int cabId;
	private String cabNumber;
	private String cabType;
	private String status;
	@Autowired
	private Location location;
	@Autowired
	private Driver Driver;
	
	
	Cab(int cabId,String cabNumber,String cabType,String status,Location location,Driver driver){
		this.cabNumber=cabNumber;
		this.cabType=cabType;
		this.location=location;
		this.status=status;
		this.Driver=driver;
		
	}

	public String getCabNumber() {
		return cabNumber;
	}

	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}

	public String getCabType() {
		return cabType;
	}

	public void setCabType(String cabType) {
		this.cabType = cabType;
	}

	
	
	

}
