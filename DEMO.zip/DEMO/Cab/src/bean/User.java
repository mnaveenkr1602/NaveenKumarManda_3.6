package bean;

@Component
public class User {
	
	private int userId;
	private String userName;
	private int mobileNumber;
	@Autowired
	private Location location;
	
	User(int userid,String userName,int mobileNumber, Location location){
		this.userId=userid;
		this.userName=userName;
		this.mobileNumber=mobileNumber;
		this.location=location;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(int mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	
}
