package dao;

public class CabDAOImpl implements CabDAO{

	@Override
	public List<Cab> getListOfCab(Location location){
		//fetching cab from db
		List<Cab> listOfCab=new List<>();
		//logic to 
		
		return listOfCab;
	}
}
