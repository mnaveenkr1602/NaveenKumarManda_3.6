package service;

public class SearchCab {
	
	public Cab nearestCab(Trip trip, Location location) {
		//fetching cabs per location
		List<Cab> listOfCab=getListOfCabs(location);
		Cab availableCab=new Cab();
		for(Cab i:listOfCab) {
			if(cab.getStatus.equals("Available")) {
				cab=i;
				break;
			}
		}
		
		return cab
		
	}

}
