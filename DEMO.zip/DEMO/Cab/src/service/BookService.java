package service;

@Service
public class BookService {

	public String getBookStatus(Trip trip, Location location) {
		//Finding availabe cab
		String status="Not Booked";
		Cab cab=nearestCab(trip,location);
		if(cab!=null) {
			status="BOOKED";
		}
		
		return status;
	}
}
