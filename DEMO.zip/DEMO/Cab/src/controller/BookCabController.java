package controller;

@RestController
public class BookCabController {
	
	@Autowired
	private BookService bookService

	@RequestMapping(value="/book",method=RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<?> bookCab(@RequestBody Trip trip,@RequestBody Location currentLocation)){
		
		String bookingStatus="";
		String CabStatus="";
		try {
			CabStatus=bookService.getBookingStatus(trip,currentLocation);
			if(CabStatus.equals("BOOKED")) {
				bookingStatus="SUCCESS";
			}
		}catch(Exception e) {
			bookingStatus="Failed to book the cab";
		}
		if(bookingStatus.equals("SUCCESS"))
			return new ResponseEntity<String>(bookingStatus,HttpStatus.OK);
		else
			return new ResponseEntity<String>(bookingStatus,HttpStatus.InternalServerError);

	}
	
}
