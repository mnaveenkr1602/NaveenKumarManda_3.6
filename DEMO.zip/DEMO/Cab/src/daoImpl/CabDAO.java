package daoImpl;

public interface CabDAO {
	
	public List<Cab> getListOfCab(location);

}
